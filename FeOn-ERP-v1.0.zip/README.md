# FeOn ERP v1.0

FeOn silikon hamur üretimi için mobil uyumlu başlangıç ERP sürümü.

## Modüller
- Kontrol paneli
- Hammadde stok ve silme
- Satın alma
- Reçete yönetimi (50 kg hedef uyarısı verir, yine de kaydeder)
- Üretim ve reçeteye göre stok düşümü
- Sipariş oluşturma ve silme
- Finans
- JSON yedekleme / geri yükleme

## Kullanım
`index.html` dosyasını tarayıcıda açın. Veriler cihazın tarayıcısında saklanır.

## GitHub Pages
Repository Settings > Pages > Deploy from a branch > main / root seçilerek yayınlanabilir.
